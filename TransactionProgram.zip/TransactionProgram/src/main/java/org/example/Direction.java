package org.example;

public enum Direction {
    BUY,
    SELL
}
