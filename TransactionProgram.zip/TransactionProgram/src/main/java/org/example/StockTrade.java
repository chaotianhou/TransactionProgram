package org.example;

public class StockTrade extends Trade {
    private String code;
    private Long quantity;

    public String getCode() {
        return code;
    }

    public Long getQuantity() {
        return quantity;
    }
    public StockTrade(Long id, Long tradeId, Long version, String code, Long quantity, Action action, Direction direction) {
        super(id, tradeId, version, action, direction);
        this.code = code;
        this.quantity = quantity;
    }
}
