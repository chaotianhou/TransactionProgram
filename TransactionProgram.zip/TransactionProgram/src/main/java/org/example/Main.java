package org.example;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        StockService stockService = new StockService();
        List<StockTrade> sts = new ArrayList<>();
        sts.add(new StockTrade(1L, 1L, 1L, "REL", 50L, Action.INSERT, Direction.BUY));
        sts.add(new StockTrade(2L, 2L, 1L, "ITC", 40L, Action.INSERT, Direction.SELL));
        sts.add(new StockTrade(3L, 3L, 1L, "INF", 70L, Action.INSERT, Direction.BUY));
        sts.add(new StockTrade(4L, 1L, 2L, "REL", 60L, Action.UPDATE, Direction.BUY));
        sts.add(new StockTrade(5L, 2L, 2L, "ITC", 30L, Action.CANCEL, Direction.BUY));
        sts.add(new StockTrade(6L, 4L, 1L, "INF", 20L, Action.INSERT, Direction.SELL));
        stockService.process(sts);
        System.out.println(stockService.generatePositions());
    }
}