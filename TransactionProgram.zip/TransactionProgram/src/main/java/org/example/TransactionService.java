package org.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface TransactionService<T extends Trade> {
    void process(T t);
    void process(List<T> lt);
}
