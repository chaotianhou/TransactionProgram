package org.example;

public class Trade {
    private Long id;
    private Long tradeId;
    private Long version;
    private Action action;
    private Direction direction;

    public Trade(Long id, Long tradeId, Long version, Action action, Direction direction) {
        this.id = id;
        this.tradeId = tradeId;
        this.version = version;
        this.action = action;
        this.direction = direction;
    }


    public Long getId() {
        return id;
    }
    public Long getTradeId() {
        return tradeId;
    }
    public Long getVersion() {
        return version;
    }
    public Action getAction() {
        return action;
    }
    public Direction getDirection() {
        return direction;
    }
}
