package org.example;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StockService implements TransactionService<StockTrade> {

    Map<Long, StockTrade> stockMap = new HashMap<>();

    public Map<Long, StockTrade> getStocks() {
        return stockMap;
    }

    @Override
    public void process(StockTrade st) {
        switch (st.getAction()) {
            case CANCEL -> stockMap.remove(st.getTradeId());
            case INSERT, UPDATE -> stockMap.put(st.getTradeId(), st);
            default -> System.out.println("Unrecognized action.");
        }
    }

    @Override
    public void process(List<StockTrade> sts) {
        sts.sort(Comparator.comparing(Trade::getId));
        for (StockTrade st : sts) {
            process(st);
        }
    }

    public Map<String, Long> generatePositions() {
        Map<String, Long> positions = new HashMap<>();
        for (Map.Entry<Long, StockTrade> entry: stockMap.entrySet()) {
            StockTrade st = entry.getValue();
            String code = st.getCode();
            Long quantity = positions.getOrDefault(code, 0L);
            switch (st.getDirection()) {
                case BUY -> positions.put(code, quantity + st.getQuantity());
                case SELL -> positions.put(code, quantity - st.getQuantity());
                default -> System.out.println("Unrecognized direction.");
            }
        }
        return positions;
    }
}
