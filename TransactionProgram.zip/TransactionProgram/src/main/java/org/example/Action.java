package org.example;

public enum Action {
    INSERT,
    UPDATE,
    CANCEL;
}
